<?php
    $num1 = 5;
    $num2 = 10;

    $soma = $num1 + $num2;

    echo "A soma de ".$num1." + ".$num2." é igual a ".$soma;
    //echo "A soma de $num1 + $num2 é igual a $soma";





?>